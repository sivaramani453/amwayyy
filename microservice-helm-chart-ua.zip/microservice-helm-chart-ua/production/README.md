Production microservice helm charts (not managed by CI)

To update production chart:
Prerequsites:
1. Ensure you have helm v3 
2. Install helm push plugin - helm plugin install https://github.com/chartmuseum/helm-push.git)
3. Add prod chartmuseum to helm repo list - helm repo add chartmuseum https://chartmuseum3.ru.eia.amway.net

From chart directory:
helm push . chartmuseum

