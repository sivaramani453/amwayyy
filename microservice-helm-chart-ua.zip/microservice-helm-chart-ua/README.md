### HOWTO Deploy microservice with Helm v3

- Create GitHub self-hosted agents;
- Add  secrets&service users;
- Create workflow yaml;
- Create docker repository;
- Configure helm-charts;

## For Production
- Prepare helm-chart;
- Push manualy to chartmuseum;


## Create GitHub self-hosted agents

Add new microservice to [locals.tf](https://github.com/AmwayACS/lynx-ru-iac/blob/main/terraform/github-actions/ecs-self-hosted/locals.tf "locals.tf") 




      ###################################
      #         %microservice-name%           #
      
      ###################################
      git_org = "AmwayACS"

      git_repo           = "%microservice-repo%"
      git_token          = "${var.git_token}"
      runners            = 1
      labels             = "dev,spot"
      init_image         = "amway/actions-init:0.3"
      runner_image       = "amway/actions-runner:2.273.5-2"
      runner_memory_soft = 256
      runner_memory_hard = 256

      # job settings
      sonar_url = "*will change*"

      # docker machine settings (if capacity)
      dm_az             = "b"
      dm_region         = "${data.aws_region.current.name}"
      dm_vpc_id         = "${data.terraform_remote_state.core.vpc.dev.id}"
      dm_subnet_id      = "${data.terraform_remote_state.core.subnet.ci_b.id}"
      dm_is_spot        = "no"                                                 # yes or no
      dm_block_duration = 60
      dm_instance_type  = "t3a.medium"
    },`

After that from local machine run *terraform apply*.


## Add  secrets&service users

**Add secrets:**
`DOCKER_USER; DOCKER_PASSWORD; NEXUS_USER; NEXUS_PASSWORD;`
Secrets store at Vault.

**Add git service users**
- DrZoidbergRU 
- RUJMKQ6 

## **Add to microservice repository build file**

Put to repository **.github/workflows/build_deploy.yaml** and don't forget edit docker image name:
```yaml
name: Check and Build

on:
  push:
  release:
    types: [ published ]

env:
  # gradle tests step yes/no
  GRADLE_UNIT_TEST: yes
  GRADLE_SONAR_TEST: no
  # Docker image name
  DOCKER_TARGET_IMAGE: %docker_image_name%

  # Global env vars
  MACHINE_NAME: "dm-${{ github.run_id }}"

  WORKDIR: /work
  SHARED: shared_volume
  GRADLE_HOME: /home/gradle
  DOCKER_SOCK: /var/run/docker.sock

  SONAR_ANALYSIS_MODE: publish

  DOCKER_ALPINE_IMAGE: alpine
  DOCKER_BUILDER_IMAGE: docker:18-git
  DOCKER_GRADLE_IMAGE: gradle:7-jdk11
  DOCKER_REGISTRY_DEV: nexus.hybris.eia.amway.net:8083
  DOCKER_REGISTRY_PROD: amway


jobs:
  main:
    runs-on: self-hosted
    # Tricky way to run on regular pushes and cancel duplicated wf when release is published
    if: ${{ github.event_name == 'release' || github.event_name == 'push' && startsWith(github.ref, 'refs/heads')}}

    steps:      
      - name: Create Docker machine
        shell: bash
        run: |
          DM_EXTRA_OPTS=""
          if [ $MACHINE_IS_SPOT == "yes" ]; then
              DM_EXTRA_OPTS="--amazonec2-request-spot-instance --amazonec2-block-duration-minutes $MACHINE_DURATION"
          fi
          docker-machine create --driver amazonec2 \
                                --amazonec2-region $MACHINE_REGION \
                                --amazonec2-instance-type $MACHINE_TYPE\
                                --amazonec2-security-group $MACHINE_SG_NAME \
                                --amazonec2-subnet-id $MACHINE_SUBNET \
                                --amazonec2-vpc-id $MACHINE_VPC_ID \
                                --amazonec2-zone $MACHINE_AZ \
                                --amazonec2-private-address-only \
                                $DM_EXTRA_OPTS \
                                $MACHINE_NAME
     
      - name: Create shared volume
        shell: bash
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker volume create $SHARED
      - name: Login to DockerHub(limits)
        shell: bash
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker login -u ${{ secrets.DOCKERHUB_USER }} -p ${{ secrets.DOCKERHUB_PASSWORD }}
          
      - name: Clone repo
        shell: bash
        env:
          GIT_USER: EUJJZU8
        run: |
          REF=$(echo $GITHUB_REF | sed -E 's:refs/(heads|tags)/::')
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker run --rm -v $SHARED:$WORKDIR \
                          -w $WORKDIR $DOCKER_ALPINE_IMAGE \
                          /bin/sh -c "apk add git \
                                      && git clone -b $REF https://$GIT_USER:${{ secrets.GITHUB_TOKEN }}@github.com/$GITHUB_REPOSITORY ${GITHUB_REPOSITORY##*/} \
                                      && chown -R 1000:1000 ${GITHUB_REPOSITORY##*/}"
      - name: Gradle assemble
        shell: bash
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker run --rm -v $SHARED:$GRADLE_HOME \
                          -w "$GRADLE_HOME/${GITHUB_REPOSITORY##*/}" $DOCKER_GRADLE_IMAGE \
                          /bin/sh -c "gradle assemble; ls -al build; ls -al build/libs"
      - name: Gradle unit test
        if: ${{ env.GRADLE_UNIT_TEST == 'yes' }}
        shell: bash
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker run --rm -u root \
                          -v $SHARED:$GRADLE_HOME \
                          -v $DOCKER_SOCK:$DOCKER_SOCK \
                          -w "$GRADLE_HOME/${GITHUB_REPOSITORY##*/}" $DOCKER_GRADLE_IMAGE \
                          /bin/sh -c "gradle test"
      - name: Sonar test
        if: ${{ env.GRADLE_SONAR_TEST == 'yes' }}
        shell: bash
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker run --rm -u root \
                          -v $SHARED:$GRADLE_HOME \
                          -w "$GRADLE_HOME/${GITHUB_REPOSITORY##*/}" $DOCKER_GRADLE_IMAGE \
                          /bin/sh -c "gradle sonarqube -Dsonar.host.url=$SONAR_URL -Dsonar.analysis.mode=$SONAR_ANALYSIS_MODE -x test"
      - name: Docker build
        shell: bash
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker login -u ${{ secrets.DOCKERHUB_USER }} -p ${{ secrets.DOCKERHUB_PASSWORD }}
          docker run --rm -u root \
                          -v $SHARED:$WORKDIR \
                          -v $DOCKER_SOCK:$DOCKER_SOCK \
                          -w "$WORKDIR/${GITHUB_REPOSITORY##*/}" $DOCKER_BUILDER_IMAGE \
                          /bin/sh -c "docker build -t $DOCKER_TARGET_IMAGE ."
      - name: Docker push nexus (latest)
        shell: bash
        if: ${{ github.ref == 'refs/heads/dev-dev' }}
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker login -u ${{ secrets.NEXUS_USER }} -p "${{ secrets.NEXUS_PASSWORD }}" $DOCKER_REGISTRY_DEV
          docker tag $DOCKER_TARGET_IMAGE $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE
          docker push $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE
      - name: Docker push Nexus (tagged)
        run: |
          REF=$(echo $GITHUB_REF | sed -E 's:refs/(heads|tags)/::'| sed -E "s:[^0-9a-zA-Z.-]:_:g")
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker login -u docker -p docker $DOCKER_REGISTRY_DEV
          docker tag $DOCKER_TARGET_IMAGE $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE:$REF-${GITHUB_SHA:0:8}
          docker push $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE:$REF-${GITHUB_SHA:0:8}
      - name: Docker push Dockerhub (git release)
        if: ${{ github.event_name == 'release' }}
        run: |
          REF=$(echo $GITHUB_REF | sed -E 's:refs/(heads|tags)/::'| sed -E "s:[^0-9a-zA-Z.-]:_:g")
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker login -u ${{ secrets.DOCKERHUB_USER }} -p ${{ secrets.DOCKERHUB_PASSWORD }}
          docker tag $DOCKER_TARGET_IMAGE $DOCKER_REGISTRY_PROD/$DOCKER_TARGET_IMAGE:$REF
          docker push $DOCKER_REGISTRY_PROD/$DOCKER_TARGET_IMAGE:$REF
      - name: Docker push Nexus  (git release)
        if: ${{ github.event_name == 'release' }}
        run: |
          REF=$(echo $GITHUB_REF | sed -E 's:refs/(heads|tags)/::'| sed -E "s:[^0-9a-zA-Z.-]:_:g")
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker login -u docker -p docker $DOCKER_REGISTRY_DEV
          docker tag $DOCKER_TARGET_IMAGE $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE:$REF
          docker push $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE:$REF
      - name: Summary
        shell: bash
        run: |
          REF=$(echo $GITHUB_REF | sed -E 's:refs/(heads|tags)/::'| sed -E "s:[^0-9a-zA-Z.-]:_:g")
          # Print image name
          if [ $GITHUB_EVENT_NAME == "release" ]; then
              echo "Prod image was built: $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE:$REF"
              echo "Prod image was built: $DOCKER_REGISTRY_PROD/$DOCKER_TARGET_IMAGE:$REF"
          else
              echo "Dev image was built: $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE:$REF-${GITHUB_SHA:0:8}"
          fi
          # If latest was built
          if [ $REF == "dev-dev" ]; then
              echo "dev-dev image was built: $DOCKER_REGISTRY_DEV/$DOCKER_TARGET_IMAGE:latest"
          fi
      - name: Terminate instance
        shell: bash
        if: ${{ always() }}
        run: |
          eval $(docker-machine env $MACHINE_NAME --shell bash)
          docker-machine rm -y $MACHINE_NAME
      - name: Clean up.
        shell: bash
        if: ${{ always() }}
        run: |
          rm -rf *
```
## **Create docker repository**

Ask @Konstantin_Mantrov to create repository at dockerHub.

## **Configure helm-charts**
Create Helm Chart v3 for microservice in repository [microservice-helm-chart-v3](https://github.com/AmwayACS/microservice-helm-chart-v3 "microservice-helm-chart-v3"). Use for Non-Production envs Chart version 3.0.x. Before push to repository check your helm chart via **helm lint**.

## **For Production**

**!!!Attention!!!** Deploy Helm Chart fron production only from your local machine. So before please clone repo.
- For Production services create Chart in folder [production](https://github.com/AmwayACS/microservice-helm-chart-v3/tree/dev/production "production") and user Chart version 1.0.x.
- Install helm push plugin - **helm plugin install** https://github.com/chartmuseum/helm-push.git
- Add prod chartmuseum to helm repo list - **helm repo add chartmuseum** https://chartmuseum3.ru.eia.amway.net
- From chart directory: **helm push . chartmuseum**

## Go to Runcher and deploy new microservice :)
