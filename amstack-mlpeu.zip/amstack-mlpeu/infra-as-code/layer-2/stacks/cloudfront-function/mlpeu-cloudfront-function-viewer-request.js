/*
@Author SRE Team.
Cloudfront Function Viewer Request.
*/

//configurations for URI redirection
var URI_REDIRECTIONS = [];

// values of production environment should come first before lower.
var NAKED_DOMAINS = [
    'mlp.uat.amway.it',
    'mlp.nft.amway.it',
    'mlp.dev3.amway.it',
    'mlp.sit.amway.it'
]

function handler(event) {
    var redirect = redirectRequest(event);

    if (redirect !== undefined) {
        return redirect;
    }

    // Add session cookie in user requests
    var xamsserveridValue = null;
    if (event.request.cookies.hasOwnProperty('xamsserverid')) {
        xamsserveridValue = event.request.cookies['xamsserverid'].value;
    }
    if (!xamsserveridValue || xamsserveridValue.length === 0) {
        var request = event.request;
        request.cookies['xamsserverid'] = { "value": event.context.requestId };
        request.headers['xamsserverid'] = { "value": "true" };
        return request;
    }

    return event.request;
}

//Gateway function to user request redirects
function redirectRequest(event) {
    var request = event.request;
    var headers = request.headers;
    var uri = request.uri;
    var host = headers.host.value;
    var loc = "";
    // var redirect = undefined;
    var redirected = false;
    var redirectedHost = undefined;
    var decofeRedirect = undefined;

    //Redirect user request to www.
    redirectedHost = nakedDomainRedirection(host);
    if (redirectedHost) {
        host = redirectedHost;
        redirected = true;
    }

    // //Path redirect
    // redirect = uriRedirect(host, uri);
    // if (redirect) {
    //     uri = redirect;
    //     redirected = true;
    // }

    //Decofe Alias redirect
    decofeRedirect = redirection_alias(event);
    if (decofeRedirect) {
        uri = decofeRedirect.uri;
        redirected = true;
    }

    if (redirected === true) {
        if (Object.keys(request.querystring).length)
            loc = `https://${host}${uri}?${objectToQueryString(request.querystring)}`
        else
            loc = `https://${host}${uri}`

        var response = {
            statusCode: 301,
            statusDescription: 'Redirection',
            headers: {
                "location": { value: `${loc}` }
            }
        }
        return response;
    }

    return undefined;
}

//Redirect user request to www.
function nakedDomainRedirection(host) {
    if (NAKED_DOMAINS.includes(host)) {
        host = `www.${host}`
        return host;
    }
    return undefined;
}

function uriRedirect(host, uri) {
    //Path redirect only if path already not exists in uri
    for (var index in URI_REDIRECTIONS) {
        var rule = URI_REDIRECTIONS[index];
        var redirect = rule.redirect;
        var skip = rule.skip_uri;
        var exact = rule.exact_uri;

        //skip_uri and exact_uri wont work at the same time
        if (rule.host.includes(host) && !uri.startsWith(redirect)) {

            //Redirect will happen if exact_uri is matched
            if (exact !== undefined && exact.includes(uri)) {
                return `${redirect}${exact}`
            }

            //skip_uri will work only if exact_uri config is missing
            if (skip !== undefined && !isUriSkip(uri, skip)) {
                return `${redirect}${uri}`
            }

            if (exact === undefined && skip === undefined) {
                return `${redirect}${uri}`
            }

        }

    }
    return undefined;
}

function isUriSkip(uri, skips) {
    for (var index in skips) {
        var skip = skips[index];
        if (uri.includes(skip) === true) {
            return true;
        }
    }
    return false;
}

function objectToQueryString(obj) {
    var str = [];
    for (var param in obj) {
        if (obj[param].value == '') {
            str.push(encodeURIComponent(param));
        } else {
            if (obj[param].multiValue) {
                obj[param].multiValue.forEach(val => {
                    str.push(encodeURIComponent(param) + "=" + encodeURIComponent(val.value));
                });
            } else {
                str.push(encodeURIComponent(param) + "=" + encodeURIComponent(obj[param].value));
            } //in case of single value query
        }
    }
    return str.join("&");
}
// Redirection for invitation id
function redirection_alias(event) {
    var request       = event.request;
    var uri           = request.uri;
    var queryparam    = request.querystring;
    var split_url     = uri.split("/");
    var id            = split_url.pop() || split_url.pop();
    // Match URI
    if (uri.endsWith('it/login/register/downliner/invitation/'+ id)) {
        request.uri = '/it';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'1'};

        return request;
    }
    else if (uri.endsWith('en/login/register/downliner/invitation/'+ id)) {
        request.uri = '/en';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'1'};

        return request;
    }
    else if (uri.endsWith('zh/login/register/downliner/invitation/'+ id)) {
        request.uri = '/zh';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'1'};

        return request;
    }
    else if (uri.endsWith('login/register/downliner/invitation/'+ id)) {
        request.uri = '/';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'1'};

        return request;
    }
    else if (uri.endsWith('it/unsubscribe/invitation/'+ id)) {
        request.uri = '/it';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'5'};

        return request;
    }
    else if (uri.endsWith('en/unsubscribe/invitation/'+ id)) {
        request.uri = '/en';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'5'};

        return request;
    }
    else if (uri.endsWith('zh/unsubscribe/invitation/'+ id)) {
        request.uri = '/zh';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'5'};

        return request;
    }
    else if (uri.endsWith('unsubscribe/invitation/'+ id)) {
        request.uri = '/';
        queryparam.invitation_id = {value:id};
        queryparam.opt = {value:'5'};

        return request;
    }
    else if (uri.endsWith('en/my-account/returns/'+ id)) {
        request.uri = '/en/return-refund-tracker/'+ id;

        return request;
    }
    else if (uri.endsWith('en/my-account/order/'+ id)) {
        request.uri = '/en/order-details/'+ id;

        return request;
    }
    else if (uri.endsWith('en/my-account/my-customers/orders/orderDetails/'+ id)) {
        request.uri = '/en/customer-reports/order-list/'+ id;

        return request;
    }
    else if (uri.endsWith('it/my-account/returns/'+ id)) {
        request.uri = '/it/return-refund-tracker/'+ id;

        return request;
    }
    else if (uri.endsWith('it/my-account/order/'+ id)) {
        request.uri = '/it/order-details/'+ id;

        return request;
    }
    else if (uri.endsWith('it/my-account/my-customers/orders/orderDetails/'+ id)) {
        request.uri = '/it/customer-reports/order-list/'+ id;

        return request;
    }
    else if (uri.endsWith('zh/my-account/returns/'+ id)) {
        request.uri = '/zh/return-refund-tracker/'+ id;

        return request;
    }
    else if (uri.endsWith('zh/my-account/order/'+ id)) {
        request.uri = '/zh/order-details/'+ id;

        return request;
    }
    else if (uri.endsWith('zh/my-account/my-customers/orders/orderDetails/'+ id)) {
        request.uri = '/zh/customer-reports/order-list/'+ id;

        return request;
    }
    else if (uri.endsWith('my-account/returns/'+ id)) {
        request.uri = '/return-refund-tracker/'+ id;

        return request;
    }
    else if (uri.endsWith('my-account/order/'+ id)) {
        request.uri = '/order-details/'+ id;

        return request;
    }
    else if (uri.endsWith('my-account/my-customers/orders/orderDetails/'+ id)) {
        request.uri = '/customer-reports/order-list/'+ id;

        return request;
    }

    return undefined;
}