/*
@Author SRE Team.
Cloudfront Function Viewer Request.
*/

//configurations for URI redirection
var URI_REDIRECTIONS = [];

// values of production environment should come first before lower.
var NAKED_DOMAINS = [
]

function handler(event) {
    var redirect = redirectRequest(event);

    if (redirect !== undefined) {
        return redirect;
    }

    // Add session cookie in user requests
    var xamsserveridValue = null;
    if (event.request.cookies.hasOwnProperty('xamsserverid')) {
        xamsserveridValue = event.request.cookies['xamsserverid'].value;
    }
    if (!xamsserveridValue || xamsserveridValue.length === 0) {
        var request = event.request;
        request.cookies['xamsserverid'] = { "value": event.context.requestId };
        request.headers['xamsserverid'] = { "value": "true" };
        return request;
    }

    return event.request;
}

//Gateway function to user request redirects
function redirectRequest(event) {
    var request = event.request;
    var headers = request.headers;
    var uri = request.uri;
    var host = headers.host.value;
    var loc = "";
    var redirect = undefined;
    var redirected = false;
    var redirectedHost = undefined;

    //Redirect user request to www.
    redirectedHost = nakedDomainRedirection(host);
    if (redirectedHost) {
        host = redirectedHost;
        redirected = true;
    }

    //Path redirect
    redirect = uriRedirect(host, uri);
    if (redirect) {
        uri = redirect;
        redirected = true;
    }

    if (redirected === true) {
        if (Object.keys(request.querystring).length)
            loc = `https://${host}${uri}?${objectToQueryString(request.querystring)}`
        else
            loc = `https://${host}${uri}`

        var response = {
            statusCode: 301,
            statusDescription: 'Redirection',
            headers: {
                "location": { value: `${loc}` }
            }
        }
        return response;
    }

    return undefined;
}

//Redirect user request to www.
function nakedDomainRedirection(host) {
    if (NAKED_DOMAINS.includes(host)) {
        host = `www.${host}`
        return host;
    }
    return undefined;
}

function uriRedirect(host, uri) {
    //Path redirect only if path already not exists in uri
    for (var index in URI_REDIRECTIONS) {
        var rule = URI_REDIRECTIONS[index];
        var redirect = rule.redirect;
        var skip = rule.skip_uri;
        var exact = rule.exact_uri;

        //skip_uri and exact_uri wont work at the same time
        if (rule.host.includes(host) && !uri.startsWith(redirect)) {

            //Redirect will happen if exact_uri is matched
            if (exact !== undefined && exact.includes(uri)) {
                return `${redirect}${exact}`
            }

            //skip_uri will work only if exact_uri config is missing
            if (skip !== undefined && !isUriSkip(uri, skip)) {
                return `${redirect}${uri}`
            }

            if (exact === undefined && skip === undefined) {
                return `${redirect}${uri}`
            }

        }

    }
    return undefined;
}

function isUriSkip(uri, skips) {
    for (var index in skips) {
        var skip = skips[index];
        if (uri.includes(skip) === true) {
            return true;
        }
    }
    return false;
}

function objectToQueryString(obj) {
    var str = [];
    for (var param in obj) {
        if (obj[param].value == '') {
            str.push(encodeURIComponent(param));
        } else {
            if (obj[param].multiValue) {
                obj[param].multiValue.forEach(val => {
                    str.push(encodeURIComponent(param) + "=" + encodeURIComponent(val.value));
                });
            } else {
                str.push(encodeURIComponent(param) + "=" + encodeURIComponent(obj[param].value));
            } //in case of single value query
        }
    }
    return str.join("&");
}