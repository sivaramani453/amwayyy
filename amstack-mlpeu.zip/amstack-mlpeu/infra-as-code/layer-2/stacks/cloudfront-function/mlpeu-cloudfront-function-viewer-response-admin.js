/*
@Author SRE Team.
Cloudfront Function Viewer Response.
*/
function handler(event) {
    if (event.request.headers.hasOwnProperty('xamsserverid')) {
        var response = event.response;
        response.cookies['xamsserverid'] = {
            "value": event.context.requestId,
            "attributes": "Max-Age=7200; Path=/; HttpOnly; SameSite=None; Secure"
        }
        return response;
    }
    return event.response;
}
