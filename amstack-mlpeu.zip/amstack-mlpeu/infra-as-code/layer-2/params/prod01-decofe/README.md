# amstack-mlpeu (infra-as-code)

# PROD

## Terraform Apply Prod01 (Layer 2)

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-decofe  --reset-terraform true -s cloudfront-function
```

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-decofe  --reset-terraform true -s cloudfront-origin-request-policy
```

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-decofe  --reset-terraform true -s cloudfront-policy
```

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-decofe  --reset-terraform true -s cloudfront-response-headers-policy
```