# amstack-eu (infra-as-code)


# PROD


## Terraform Apply Prod01 (Layer 2)

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-common  --reset-terraform true -s cloudfront-policy
```

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-hybris  --reset-terraform true -s efs
```

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-hybris  --reset-terraform true -s waf
```

```console
bash setup.sh -r eu-central-1 -l 2 -e prod01-hybris  --reset-terraform true -s dms
```

```console
## before Apply this, Please update Database Password to the EndPoint.
bash setup.sh -r eu-central-1 -l 2 -e prod01-hybris  --reset-terraform true -s dms-task
```


# PREPROD02

## Terraform Apply Prepod02 (Layer 2)

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-common  --reset-terraform true -s cloudfront-policy
```

```console(Skipped as source bucket(EU) is in same AWS account)
bash setup.sh -r eu-central-1 -l 2 -e preprod02-common  --reset-terraform true -s iam-user-custom-policy
```

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-hybris  --reset-terraform true -s efs
```

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-hybris  --reset-terraform true -s waf
```

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-hybris  --reset-terraform true -s dms
```

```console
## before Apply this, Please update Database Password to the EndPoint.
bash setup.sh -r eu-central-1 -l 2 -e preprod02-hybris  --reset-terraform true -s dms-task
```

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-hybris  --reset-terraform true -s dms-event-subscription
```
