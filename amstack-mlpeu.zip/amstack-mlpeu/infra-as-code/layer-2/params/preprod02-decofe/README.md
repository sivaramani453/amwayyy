# amstack-mlpeu (infra-as-code)


# PREPROD02


## Terraform Apply Preprod02 (Layer 2)


```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-decofe  --reset-terraform true -s cloudfront-function
```

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-decofe  --reset-terraform true -s cloudfront-origin-request-policy
```

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-decofe  --reset-terraform true -s cloudfront-policy
```

```console
bash setup.sh -r eu-central-1 -l 2 -e preprod02-decofe  --reset-terraform true -s cloudfront-response-headers-policy
```