import json

def lambda_handler(event, context):
    origin = event['headers']['origin'] if 'origin' in event['headers'] else ""
    response = {
        'statusCode': 200,
        'body': json.dumps({'message': 'Hello! Lambda Working'})
    }

    response['headers'] = {
        'Access-Control-Allow-Origin': origin
    }
    return response