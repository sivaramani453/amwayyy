# amstack-mlpeu (infra-as-code)


## Terraform Apply Preprod02 MLPEU DEV2 (Layer 3)

```console
cd infra-as-code
```

### ACM Certificate(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-acm-certificate
```

### S3 Bucket(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-s3-bucket
```

### IAM User Policy
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-iam-user-custom-policy
```

### Service Account IAM Role
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-service-account-iam-role
```

### SSM Parameters
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-ssm
```

### SSM Secure Parameters
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-ssm-secure
```

### WebACL(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-web-acl
```

### WAF Rule Group(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-waf-rule-group
```

### CloudFront Distribution(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-cloudfront
```

### AWS Shield
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-shield
```

### DB Parameter Group(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-hybris-dev2  --reset-terraform true -s hybris-db-parameter-group
```
