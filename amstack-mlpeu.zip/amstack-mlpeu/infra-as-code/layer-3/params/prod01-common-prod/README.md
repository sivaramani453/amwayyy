# amstack-eu (infra-as-code)


## Terraform Apply ITALY Prod01 DECOFE (Layer 3)

```console
cd infra-as-code
```

### API Gateway(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-common-prod  --reset-terraform true -s common-apigw
```
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-common-prod  --reset-terraform true -s common-apigw-blue
```
