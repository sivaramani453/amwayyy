# amstack-eu (infra-as-code)


## Terraform Apply ITALY Prod01 cc (Layer 3)

```console
cd infra-as-code
```

### ACM Certificate(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-acm-certificate
```

### KMS Key(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-kms-key
```

### S3 Bucket(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-s3-bucket
```

### IAM User Policy
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-iam-user-custom-policy

```

### cc-lambda-iam-role
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-lambda-iam-role

### cc-lambda
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-lambda

### Blue Service Account IAM Role
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-service-account-iam-role-blue
```

### SSM Parameters
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-ssm
```

### SSM Secure Parameters
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-ssm-secure
```

### WebACL(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-web-acl
```

### API Gateway(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-apigw
```

### CloudFront Distribution(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-cloudfront
```

### AWS Shield
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-shield
```

### Route53 Records
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-route53-records
```

### DB Parameter Group(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e prod01-cc-prod  --reset-terraform true -s cc-db-parameter-group
```
