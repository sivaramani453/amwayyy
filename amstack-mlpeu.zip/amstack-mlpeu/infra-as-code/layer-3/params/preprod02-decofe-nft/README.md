# amstack-eu (infra-as-code)


## Terraform Apply MLP EU Preprod02 DECOFE (Layer 3)

```console
cd infra-as-code
```

### ACM Certificate(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-acm-certificate
```

### KMS Key(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-kms-key
```

### S3 Bucket(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-s3-bucket
```

### S3 Bucket Lifecycle Policy(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-s3-bucket-lifecycle-policy
```

### IAM User Policy
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-iam-user-custom-policy
```

### Blue Service Account IAM Role
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-service-account-iam-role-blue
```

### SSM Parameters
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-ssm
```

### SSM Secure Parameters
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-ssm-secure
```

### WebACL(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-web-acl
```

### CloudFront Distribution(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-cloudfront
```

### AWS Shield
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-shield
```

### Route53 Records
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-route53-records
```

### DB Parameter Group(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-decofe-nft  --reset-terraform true -s decofe-db-parameter-group
```
