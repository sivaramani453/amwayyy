# amstack-eu (infra-as-code)


## Terraform Apply ITALY Preprod02 DECOFE (Layer 3)

```console
cd infra-as-code
```

### API Gateway(s)
```console
bash setup.sh -r eu-central-1 -l 3 -e preprod02-common-nft  --reset-terraform true -s common-apigw
```