#!/bin/bash
# POC for reading csv file having configurations.

usage()
{
    echo "usage: test_plan [[[-f file ] | [-h]]"
}


if [ $# -eq 0 ]
then
        echo "Missing options!"
        echo "(run $0 -h for help)"
        echo ""
        exit 0
fi

Terraform=
resource=
TestSuite=
PASSWORD=
USERNAME=
if [ $# -gt 0 ]; then
  TestSuite=$1
  resource=$2
  Terraform=$3  
fi


IFS=,
dateTime=$(date +%Y-%m-%d-%H-%M-%S)
FILENAMES=( $TestSuite )
CONFIG_FILE_NAME=$(echo $TestSuite | cut -f1 -d.)

echo $Terraform
echo $TestSuite
echo $resource


for FILE_NAME in "${FILENAMES[@]}"
do
    while IFS=',' read test_region test_feature env execute mac_command newline
    do
        if [ $execute == 'N' ] || [ $execute == 'n' ] || [ $execute == 'No' ] || [ $execute == 'no' ] || [ $execute == 'NO' ]; then
            continue
        fi
        #USERNAME=$test_region$env"Username"
        #PASSWORD=$test_region$env"Password"
        
        #file="${file//[$'\t\r\n ']}"
        if [ $test_feature == $resource ] ; then           
        
        unset IFS
        #command="/start.sh $constants $object $library $file --multi --config ../../$CONFIG_FILE_NAME.json --influxdb.tags \"market=$test_region,dateTime=$dateTime\" --browsertime.my.env $env --browsertime.my.usrNm ${!USERNAME} --browsertime.my.pswd ${!PASSWORD}"
        		
		if [ $Terraform == "destroy" ] ; then
		command=$mac_command" --destroy true"
        echo $command     
        eval $command
		else
		command="$mac_command"
        echo $command     
        eval $command
		
		fi
        
		fi
    
    done < $FILE_NAME
done

# while IFS=',' read test_region test_feature env execute constants object library file extra
#     do
#         if [ $execute == 'N' ] || [ $execute == 'n' ] || [ $execute == 'No' ] || [ $execute == 'no' ] || [ $execute == 'NO' ]; then
#             continue
#         fi
#         USERNAME=$test_region$test_feature$env"Username"
#         PASSWORD=$test_region$test_feature$env"Password"
        
#         command="/start.sh $constants $object $library $file --multi --config ../../$CONFIG_FILE_NAME.json --influxdb.tags dateTime=$dateTime --browsertime.my.env $env --browsertime.my.usrNm ${!USERNAME} --browsertime.my.pswd ${!PASSWORD}"
        
#         echo $command
        
# #        new_command=$(printf '.\start.sh %s %s %s %s' "$constants" "$object" "$library" "$test_file")
        
#         cd $test_region
#         cd $env
#         #pwd
#         eval $command
#         cd ..
#         cd ..
    
#     done < $FILENAME


exit 0