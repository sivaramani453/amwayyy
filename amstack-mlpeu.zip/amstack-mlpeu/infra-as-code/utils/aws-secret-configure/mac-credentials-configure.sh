#!/bin/bash

#  The script will used to set MAC_REQUIRED_CREDENTIALS
#
# Usage
# PREPROD:  bash mac-credentials-configure.sh -e test -r us-east-1
# PROD:     bash mac-credentials-configure.sh -e prod -r us-east-1
#

echo "============================================="
echo "      AmStack AWS Secret Configure           "
echo "============================================="


# Parse the params
while [ $# -gt 0 ]; do
  case "$1" in
    --env | -e)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    ENV="${1#*=}"
    ;;
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $ENV || -z $REGION ]]; then
    echo "Please provide env and region"
    exit 1
fi

echo "Please enter DT_TOKEN"
read dt_token
if [[ -z $dt_token ]]; then
    echo "DT_TOKEN cannot be blank!"
    exit 1
fi


echo "Please enter VO_DT_INTEGRATION_KEY"
read integration_key
if [[ -z $integration_key ]]; then
    echo "VO_DT_INTEGRATION_KEY cannot be blank!"
    exit 1
fi

secret_value="{\"DT_TOKEN_$ENV\": \"$dt_token\", \"VO_DT_INTEGRATION_KEY\": \"$integration_key\"}"

aws secretsmanager put-secret-value --secret-id MAC_REQUIRED_CREDENTIALS --secret-string "$secret_value" --region $REGION

return_code=$?

if [[ $return_code == 0 ]]; then
    echo "Successfully set MAC_REQUIRED_CREDENTIALS"
fi
