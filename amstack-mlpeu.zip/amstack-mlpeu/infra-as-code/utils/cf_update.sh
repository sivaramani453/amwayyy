#!/bin/bash
set -x
TEMPDIR=$(mktemp -d)
CONFIG=$(aws cloudfront get-distribution-config --id E13OVFC0QILCRD)
ETAG=$(echo "${CONFIG}" | jq -r '.ETag')
echo "${CONFIG}" | jq '.DistributionConfig' > ${TEMPDIR}/orig.json
echo "${CONFIG}" | jq '.DistributionConfig | .DefaultCacheBehavior.LambdaFunctionAssociations.Items[0].LambdaFunctionARN= "arn:aws:lambda:us-east-1:108139614258:function:eu-common-origin-response-dev-01:9"' > ${TEMPDIR}/updated.json
aws cloudfront update-distribution --id E13OVFC0QILCRD --distribution-config file://${TEMPDIR}/updated.json --if-match "${ETAG}"
