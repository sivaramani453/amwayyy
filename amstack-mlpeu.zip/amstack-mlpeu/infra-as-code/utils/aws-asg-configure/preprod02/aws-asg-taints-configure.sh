#!/bin/bash

#  The script will find the asgs with the provided prefix arg and updates the asg tags to set taints
#
# Usage: preprod02
bash aws-asg-taints-configure.sh --asg-prefix eks-AmStackMlpEuPreprod02BlueEks-t3-2xlarge-zksolr-	--type zkSolr --region eu-central-1
bash aws-asg-taints-configure.sh --asg-prefix eks-AmStackMlpEuPreprod02BlueEks-c6i-2xlarge-istio-	--type istio --region eu-central-1
bash aws-asg-taints-configure.sh --asg-prefix eks-AmStackMlpEuPreprod02BlueEks-r6i-xlarge-	--type hybris --region eu-central-1
bash aws-asg-taints-configure.sh --asg-prefix eks-AmStackMlpEuPreprod02BlueEks-m6i-2xlarge- --type hybris --region eu-central-1
bash aws-asg-taints-configure.sh --asg-prefix eks-AmStackMlpEuPreprod02BlueEks-c6i-2xlarge-ng-	--type decofe --region eu-central-1
bash aws-asg-taints-configure.sh --asg-prefix eks-AmStackMlpEuPreprod02BlueEks-c6i-2xlarge-mng-	--type decofe --region eu-central-1

echo "============================================="
echo "   AmStack AWS ASG Create/Modify Taint Tags   "
echo "============================================="

# Parse the params
while [ $# -gt 0 ]; do
  case "$1" in
  --asg-prefix | -a)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    PREFIX="${1#*=}"
    ;;
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  --type | -t)
    if [[ "$1" != *=* ]]; then shift; fi
    TYPE="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $PREFIX || -z $REGION || -z $TYPE  ]]; then
    echo "Please provide asg-prefix, type and region"
    exit 1
fi

ASGS=$(aws autoscaling describe-auto-scaling-groups --region ${REGION} | jq '.AutoScalingGroups[].AutoScalingGroupName'| tr -d '"' | grep "^${PREFIX}")

for asg in $ASGS
do
    
    if [[ $TYPE == "hybris" ]]; then
      echo "Setting tag k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/taint=hybris to asg $asg"
      command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/taint,Value=hybris,PropagateAtLaunch=true"
    elif [[ $TYPE == "istio" ]]; then
      echo "Setting tag k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/istio=istio to asg $asg"
      command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/istio,Value=istio,PropagateAtLaunch=true"
    elif [[ $TYPE == "solr" ]]; then
      echo "Setting tag k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/solr=solr to asg $asg"
      command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/solr,Value=solr,PropagateAtLaunch=true"
    elif [[ $TYPE == "zk" ]]; then
      echo "Setting tag k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/zk=zk to asg $asg"
      command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/zk,Value=zk,PropagateAtLaunch=true"
    elif [[ $TYPE == "zkSolr" ]]; then
      echo "Setting tag k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/zkSolr=zkSolr to asg $asg"
      command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/zkSolr,Value=zkSolr,PropagateAtLaunch=true"
    elif [[ $TYPE == "dynatrace" ]]; then
      echo "Setting tag k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/dynatrace=dynatrace to asg $asg"
      command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/dynatrace,Value=dynatrace,PropagateAtLaunch=true"
    elif [[ $TYPE == "decofe" ]]; then
      echo "Setting tag k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/taint=decofe to asg $asg"
      command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/taint/amstack.sre/taint,Value=decofe,PropagateAtLaunch=true"
    fi
    fi

    echo $command
    echo "Enter yes to execute"
    read update_asg_tag
    
    if [[ $update_asg_tag == "yes" ]]; then
        echo "Executing..."
        eval $command
        echo "Executed"
    fi

done