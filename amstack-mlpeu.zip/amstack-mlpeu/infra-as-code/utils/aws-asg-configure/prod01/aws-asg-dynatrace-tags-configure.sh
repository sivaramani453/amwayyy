#!/bin/bash

#  The script will find the asgs with the provided prefix arg and updates the asg tags to set taints
#
# Usage
# bash aws-asg-dynatrace-tags-configure.sh -a eks-AmStackMlpEuProd01Eks- -r eu-central-1 #in PROD all ASG's resources need to be monitored by DT.


echo "============================================="
echo "   AmStack AWS ASG Create/Modify Dynatrace Tags   "
echo "============================================="

POSITIONAL_ARGS=()

while [[ $# -gt 0 ]]; do
  case $1 in
    --asg-prefix | -a)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    PREFIX="${1#*=}"
      ;;
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $PREFIX || -z $REGION ]]; then
    echo "Please provide asg-prefix and region"
    exit 1
fi

ASGS=$(aws autoscaling describe-auto-scaling-groups --region ${REGION} | jq '.AutoScalingGroups[].AutoScalingGroupName'| tr -d '"' | grep "^${PREFIX}")

for asg in $ASGS
do
    
    echo "Setting tag k8s.io/cluster-autoscaler/node-template/label/dynatrace-enabled=true to asg $asg"
    command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=k8s.io/cluster-autoscaler/node-template/label/dynatrace-enabled,Value=true,PropagateAtLaunch=true"
    echo $command
    echo "Enter yes to execute"
    read update_asg_tag
    
    if [[ $update_asg_tag == "yes" ]]; then
        echo "Executing..."
        eval $command
        echo "Executed"
    fi

done