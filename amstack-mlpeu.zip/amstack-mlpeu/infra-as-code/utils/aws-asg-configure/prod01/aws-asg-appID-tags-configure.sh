#!/bin/bash
# This script adds 'ApplicationID' to all ASG.
# bash aws-asg-appID-tags-configure.sh -r eu-central-1 -t APP3001095

while [ $# -gt 0 ]; do
  case "$1" in
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  --applicationid | -t)
    if [[ "$1" != *=* ]]; then shift; fi 
    APPLICATIONID="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

# Check if required arguments are provided
if [[ -z $REGION || -z $APPLICATIONID ]]; then
    echo "Please provide region and ApplicationID"
    exit 1
fi

ALLASGS=$(aws autoscaling describe-auto-scaling-groups --region ${REGION} | jq '.AutoScalingGroups[].AutoScalingGroupName'| tr -d '"')
for asg in $ALLASGS
do
  command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key="ApplicationID",Value=$APPLICATIONID,PropagateAtLaunch=true"
  
  echo $command
  echo "Enter yes to execute"
  read update_asg_tag
  
  if [[ $update_asg_tag == "yes" ]]; then
    echo "Executing..."
    eval $command
    echo "Executed"
  fi
done
