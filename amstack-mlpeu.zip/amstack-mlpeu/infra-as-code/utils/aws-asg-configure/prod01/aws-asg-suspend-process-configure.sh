#!/bin/bash

#  This script can be used to automatically modify suspended processes; AZRebalance
#
#  Usage
#  bash aws-asg-suspend-process-configure.sh -a eks-AmStackMlpEuProd01Eks -r eu-central-1
#

echo "=========================================================="
echo "      AmStack AWS ASG Modify Suspended Processes          "
echo "=========================================================="

SUSPENDED_PROCESS="AZRebalance"
# Parse the params
while [ $# -gt 0 ]; do
  case "$1" in
  --asg-prefix | -a)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    PREFIX="${1#*=}"
    ;;
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $PREFIX ]]; then
    echo "Please provide asg-prefix"
    exit 1
fi

ASGS=$(aws autoscaling describe-auto-scaling-groups --region ${REGION}| jq '.AutoScalingGroups[].AutoScalingGroupName'| tr -d '"' | grep "^${PREFIX}")

for asg in $ASGS
do

    echo "Setting suspended processes $SUSPENDED_PROCESS to asg $asg"
    command="aws autoscaling suspend-processes --region ${REGION} --auto-scaling-group-name $asg --scaling-processes $SUSPENDED_PROCESS"
    echo $command
    echo "Enter yes to execute"
    read update_asg_sus
    
    if [[ $update_asg_sus == "yes" ]]; then
        echo "Executing..."
        eval $command
        echo "Executed"
    fi

done