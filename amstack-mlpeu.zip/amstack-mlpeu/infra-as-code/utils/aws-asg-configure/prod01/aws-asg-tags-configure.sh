#!/bin/bash

#  The script will find the asgs with the provided prefix arg and updates the asg tags based on instance type
#
# Usage
# bash aws-asg-tags-configure.sh -a eks-AmStackMlpEuProd01Eks -r eu-central-1
#

echo "============================================="
echo "      AmStack AWS ASG Create/Modify Tags     "
echo "============================================="

TAG_KEY="k8s.io/cluster-autoscaler/node-template/label/nodeGroupType"

# Parse the params
while [ $# -gt 0 ]; do
  case "$1" in
  --asg-prefix | -a)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    PREFIX="${1#*=}"
    ;;
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $PREFIX || -z $REGION ]]; then
    echo "Please provide asg-prefix and region"
    exit 1
fi

ASGS=$(aws autoscaling describe-auto-scaling-groups --region ${REGION}| jq '.AutoScalingGroups[].AutoScalingGroupName'| tr -d '"' | grep "^${PREFIX}")

for asg in $ASGS
do
    #Assuming the asg will have only one instance type
    launch_template_name=$(aws autoscaling describe-auto-scaling-groups --region ${REGION} --auto-scaling-group-names ${asg} | jq '.AutoScalingGroups[].MixedInstancesPolicy.LaunchTemplate.LaunchTemplateSpecification.LaunchTemplateName'| tr -d '"')
    
    #In case asg doesn't have mixedinstancespolicy
    if [[ $launch_template_name == "null" ]]; then
        launch_template_name=$(aws autoscaling describe-auto-scaling-groups --region ${REGION} --auto-scaling-group-names ${asg} | jq '.AutoScalingGroups[].LaunchTemplate.LaunchTemplateName'| tr -d '"')
    fi
    
    launch_template_version=$(aws ec2 describe-launch-templates --region ${REGION} --launch-template-names ${launch_template_name}| jq '.LaunchTemplates[0].LatestVersionNumber')
    instance_type=$(aws ec2 describe-launch-template-versions --region ${REGION} --launch-template-name ${launch_template_name} --versions ${launch_template_version} | jq '.LaunchTemplateVersions[0].LaunchTemplateData.InstanceType' | tr -d '"')
    instance_type=$(echo $instance_type | tr '.' '-')
    
    echo "Setting tag $TAG_KEY=$instance_type-ng to asg $asg"
    command="aws autoscaling create-or-update-tags --region ${REGION} --tags ResourceId=$asg,ResourceType=auto-scaling-group,Key=$TAG_KEY,Value=$instance_type-ng,PropagateAtLaunch=true"
    echo $command
    echo "Enter yes to execute"
    read update_asg_tag
    
    if [[ $update_asg_tag == "yes" ]]; then
        echo "Executing..."
        eval $command
        echo "Executed"
    fi

done