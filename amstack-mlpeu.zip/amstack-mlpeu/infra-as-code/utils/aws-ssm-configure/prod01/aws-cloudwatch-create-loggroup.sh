#!/bin/bash

# The script that create log group for storing ssm session logs
# 
# Creates a log group with the specified name and sets the retention of the specified log group. A
# retention policy allows you to configure the number of days for which to retain log events in the
# specified log group.
#
# Usage: 
# bash aws-cloudwatch-create-loggroup.sh
#
# Reference: 
# 1. https://docs.aws.amazon.com/cli/latest/reference/logs/create-log-group.html
# 2. https://docs.aws.amazon.com/cli/latest/reference/logs/put-retention-policy.html

echo "============================================="
echo "   AmStack AWS Cloudwatch log group          "
echo "============================================="

aws logs create-log-group --log-group-name amstackmlpeuprod01/ssm/sessionlogs

aws logs put-retention-policy --log-group-name amstackmlpeuprod01/ssm/sessionlogs --retention-in-days 90

aws logs tag-log-group --log-group-name amstackmlpeuprod01/ssm/sessionlogs --tags Environment=MlpEuPROD,Region=Eu,Project=AmStack,Contact=SreCore@Amway.com,ApplicationID=APP3001095,Name=amstackmlpeuprod01/ssm/sessionlogs