#!/bin/bash

# The script that create log group for storing ssm session logs
# 
# Creates a log group with the specified name and sets the retention of the specified log group. A
# retention policy allows you to configure the number of days for which to retain log events in the
# specified log group.
#
# Usage: 
# bash aws-cloudwatch-create-loggroup.sh
#
# Reference: 
# 1. https://docs.aws.amazon.com/cli/latest/reference/logs/create-log-group.html
# 2. https://docs.aws.amazon.com/cli/latest/reference/logs/put-retention-policy.html

echo "============================================="
echo "   AmStack AWS Cloudwatch log group          "
echo "============================================="

POSITIONAL_ARGS=()

while [[ $# -gt 0 ]]; do
  case $1 in
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $REGION ]]; then
    echo "Please provide region"
    exit 1
fi

aws logs create-log-group --log-group-name amstackmlpeupreprod02/ssm/sessionlogs

aws logs put-retention-policy --log-group-name amstackmlpeupreprod02/ssm/sessionlogs --retention-in-days 90

aws logs tag-log-group --log-group-name amstackmlpeupreprod02/ssm/sessionlogs --tags Environment=PREPROD02,Region=MlpEu,Project=AmStack,SubProject=EUMlp,Contact=SreCore@Amway.com,ApplicationID=APP3001211,Name=amstackmlpeupreprod02/ssm/sessionlogs