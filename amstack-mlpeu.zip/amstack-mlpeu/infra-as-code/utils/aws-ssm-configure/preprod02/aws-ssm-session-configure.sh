#!/bin/bash

# The script that configure session manager
#
# Creates a Amazon Web Services Systems Manager (SSM) document. An SSM document defines the actions
# that Systems Manager performs on your managed nodes.
# 
# Prerequiste:
# Log group must be created
# 
# Usage: 
# bash aws-ssm-session-configure.sh
# 
# Reference: 
# 1. https://docs.aws.amazon.com/cli/latest/reference/ssm/create-document.html
# 2. https://docs.aws.amazon.com/systems-manager/latest/userguide/sysman-ssm-docs.html

echo "============================================="
echo "   AmStack AWS SSM Session Manager config    "
echo "============================================="

aws ssm create-document \
    --name MlpEu2-SSM-SessionManagerRunShell \
    --content "file://SessionManagerRunShell.json" \
    --document-type "Session" \
    --document-format JSON