#!/bin/bash
# set -e
# bash configure-aws-auth.sh -c AmStackMlpEuPreprod02BlueEksCluster

while getopts c: flag
do
    case "${flag}" in
        c) CLUSTERNAME=${OPTARG};;
        *) echo "Invalid option: -$flag" ;;
    esac
done

# Mandatory Param check
if [[ -z $CLUSTERNAME ]]; then
  echo "ERROR: Clustername not provided. Required: [-c CLUSTER_NAME]"
  exit 1
fi

DATA=`echo 'mapRoles: |
    - groups:
      - system:masters
      rolearn: arn:aws:iam::386077922041:role/Euc1AmControllerProd01JenkinsAgentRoleProd01
      username: role-sre-prod-jenkins
    - groups:
      - system:masters
      rolearn: arn:aws:iam::386077922041:role/oidc-creator-role
      username: role-apac-amcontroller-prod-jumpvm
    - groups:
      - system:masters
      rolearn: arn:aws:iam::386077922041:role/oidc-creator-role-amcontroller-eu
      username: role-eu-amcontroller-prod-jumpvm
    - groups:
      - system:masters
      rolearn: arn:aws:iam::108139614258:role/AWS-CDA-MultiAccount-SREADMIN
      username: role-sre-prod-owner
    - groups:
      - system:masters
      rolearn: arn:aws:iam::386077922041:role/Apse1AmControllerProd01JenkinsAgentRole
      username: role-sre-prod-jenkins
    - groups:
      - system:masters
      rolearn: arn:aws:iam::108139614258:role/AmStackMonitoringRole
      username: role-amstack-monitoring
'`

ESCAPED_DATA="$(echo "${DATA}" | sed ':a;N;$!ba;s/\n/\\n/g' | sed 's/\$/\\$/g')"
PREVIOUS_DATA=`echo 'mapRoles: |
'`
ESCAPED_PREVIOUS_DATA="$(echo "${PREVIOUS_DATA}" | sed ':a;N;$!ba;s/\n/\\n/g' | sed 's/\$/\\$/g')"

KUBECONFIG_BASE_DIR="/root/.kube"
KUBECONFIG="$KUBECONFIG_BASE_DIR/$CLUSTERNAME"
DATE=`date  +%Y-%m-%d-%H-%M-%S`
TEMP_DIR="/tmp/${DATE}"
mkdir ${TEMP_DIR} -p

# take a backup of existing auth config
kubectl --kubeconfig $KUBECONFIG get cm/aws-auth -n kube-system -o yaml > ${TEMP_DIR}/aws-auth.yaml
echo "Existing configured backuped at ${TEMP_DIR}/aws-auth.yaml"

# append the new config
kubectl --kubeconfig $KUBECONFIG get cm/aws-auth -n kube-system -o yaml | sed "s@${PREVIOUS_DATA}@${ESCAPED_DATA}@g" | kubectl --kubeconfig $KUBECONFIG -n kube-system apply -f -