#!/bin/bash
# set -e
# bash generate-kube-config.sh -c AmStackMlpEuProd01EksCluster -r eu-central-1  #for Prod01

KUBECONFIG_BASE_DIR="/home/ssm-user/.kube"

while [ $# -gt 0 ]; do
  case "$1" in
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  --cluster_name| -c)
    if [[ "$1" != *=* ]]; then shift; fi
    CLUSTER_NAME="${1#*=}"
    ;;
  *)
    printf >&2 "Error: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $REGION && -z $CLUSTER_NAME ]]; then
  echo "Error: Please set all the required vars. Required: [--region, --cluster_name]"
  exit 1
fi

echo "==================================="
echo "Downloading Kubeconfig file for the SRE cluster"
echo "==================================="

KUBECONFIG_FILE_PATH="$KUBECONFIG_BASE_DIR/$CLUSTER_NAME"

if [ -f $KUBECONFIG_FILE_PATH ]; then
  rm $KUBECONFIG_FILE_PATH
fi

aws eks --region $REGION update-kubeconfig --name $CLUSTER_NAME --kubeconfig $KUBECONFIG_FILE_PATH
sudo chmod 400 $KUBECONFIG_FILE_PATH

echo "==================================="
echo "Connection to SRE EKS cluster"
kubectl --kubeconfig $KUBECONFIG_FILE_PATH get nodes
echo "==================================="
