REGION="eu-central-1"
# Add additional CIDR to existing VPC 
#ReadMe: Base Creation is already done as part of AmStack EU Setup.
aws cloudformation create-stack --stack-name AmStackEuCorePreprod02AddCidr --template-body file://iac-infra-create-vpcaddlcidr.yaml --parameters file://params.json --tags file://tags.json --region eu-central-1 --capabilities "CAPABILITY_NAMED_IAM" "CAPABILITY_AUTO_EXPAND"
