import sys
import boto3
from datetime import datetime
import time


def get_old_writer_instance(clusterIdentifier):
    """
    Describing DB Cluster to fetch details of writer and reader instance.
    """
    response = client.describe_db_clusters(
        DBClusterIdentifier=clusterIdentifier)
    dbClusters = response.get('DBClusters')
    if dbClusters:
        dbClusterMembers = dbClusters[0].get('DBClusterMembers')
        for dbClusterMember in dbClusterMembers:
            "If 'IsClusterWriter' is true that means that instance is a writer instance of the DB Cluster"
            if dbClusterMember['IsClusterWriter']:
                old_writer_instance = dbClusterMember['DBInstanceIdentifier']
                old_writer_response = client.describe_db_instances(
                    DBInstanceIdentifier=old_writer_instance)
                oldWriterDbInstance = old_writer_response.get('DBInstances')
                if oldWriterDbInstance:
                    oldWriterInstanceClass = oldWriterDbInstance[0].get(
                        'DBInstanceClass')
            else:
                old_reader_instance = dbClusterMember['DBInstanceIdentifier']
                old_reader_response = client.describe_db_instances(
                    DBInstanceIdentifier=old_reader_instance)
                oldReaderDbInstance = old_reader_response.get('DBInstances')
                if oldReaderDbInstance:
                    oldReaderInstanceClass = oldReaderDbInstance[0].get(
                        'DBInstanceClass')
    return old_writer_instance, oldWriterInstanceClass, old_reader_instance, oldReaderInstanceClass


def create_reader_instance(old_writer_instance, old_reader_instance, clusterIdentifier, currentwriterinstanceclass,
                           newwriterinstanceclass, currentreaderinstanceclass, newreaderinstanceclass, new_writer_instance_identifier, new_reader_instance_identifier):
    """
    Describing old writer instance to get all the required configurations 
    that will use to create new writer instances.
    """
    response = client.describe_db_instances(
        DBInstanceIdentifier=old_writer_instance)
    dbWriterInstances = response.get('DBInstances')
    dbWriterInstanceConfiguration = {}
    if dbWriterInstances:
        for dbWriterInstance in dbWriterInstances:
            dbWriterInstanceConfiguration = dbWriterInstance
            dbWriterParameterGroups = dbWriterInstanceConfiguration.get(
                'DBParameterGroups')
            for dbWriterParameterGroup in dbWriterParameterGroups:
                dbWriterInstanceParameterGroup = dbWriterParameterGroup['DBParameterGroupName']
    """
    Describing old reader instance to get all the required configurations 
    that will use to create new reader instances.
    """
    response = client.describe_db_instances(
        DBInstanceIdentifier=old_reader_instance)
    dbReaderInstances = response.get('DBInstances')
    dbReaderInstanceConfiguration = {}
    if dbReaderInstances:
        for dbReaderInstance in dbReaderInstances:
            dbReaderInstanceConfiguration = dbReaderInstance
            dbReaderParameterGroups = dbReaderInstanceConfiguration.get(
                'DBParameterGroups')
            for dbReaderParameterGroup in dbReaderParameterGroups:
                dbReaderInstanceParameterGroup = dbReaderParameterGroup['DBParameterGroupName']
    # creating reader Instance which will convert into writer instance after failover
    if currentwriterinstanceclass == newwriterinstanceclass:
        print("The current and new writer instance class is the same, so skipping the creation of the new reader instance which will convert into a writer after failover.")
    else:
        print("New writer instance creation has been started.")
        response = client.create_db_instance(
            DBInstanceIdentifier=new_writer_instance_identifier,
            DBClusterIdentifier=clusterIdentifier,
            DBInstanceClass=newwriterinstanceclass,
            Engine=dbWriterInstanceConfiguration['Engine'],
            PreferredMaintenanceWindow=dbWriterInstanceConfiguration['PreferredMaintenanceWindow'],
            DBParameterGroupName=dbWriterInstanceParameterGroup,
            PromotionTier=dbWriterInstanceConfiguration['PromotionTier'],
            EnablePerformanceInsights=dbWriterInstanceConfiguration['PerformanceInsightsEnabled'],
            AvailabilityZone=dbWriterInstanceConfiguration['AvailabilityZone'],
            Tags=[{'Key': 'Name', 'Value': new_writer_instance_identifier}],
        )
    if currentreaderinstanceclass == newreaderinstanceclass:
        print("The current and new reader instance class is the same so skipping the creation of the new reader instance.")
    else:
        # creating another reader instance which will be reader instance after failover
        response = client.create_db_instance(
            DBInstanceIdentifier=new_reader_instance_identifier,
            DBClusterIdentifier=clusterIdentifier,
            DBInstanceClass=newreaderinstanceclass,
            Engine=dbReaderInstanceConfiguration['Engine'],
            PreferredMaintenanceWindow=dbReaderInstanceConfiguration['PreferredMaintenanceWindow'],
            DBParameterGroupName=dbReaderInstanceParameterGroup,
            PromotionTier=dbReaderInstanceConfiguration['PromotionTier'],
            EnablePerformanceInsights=dbReaderInstanceConfiguration['PerformanceInsightsEnabled'],
            AvailabilityZone=dbReaderInstanceConfiguration['AvailabilityZone'],
            Tags=[{'Key': 'Name', 'Value': new_reader_instance_identifier}],
        )


def new_instances_status(currentwriterinstanceclass,
                         newwriterinstanceclass, currentreaderinstanceclass, newreaderinstanceclass, new_writer_instance_identifier, new_reader_instance_identifier):
    counter = 0
    max_counter = 20
    while True:
        counter = counter+1
        if counter < max_counter:
            if currentwriterinstanceclass != newwriterinstanceclass and currentreaderinstanceclass != newreaderinstanceclass:
                time.sleep(60)
                new_writer_instance_response = client.describe_db_instances(
                    DBInstanceIdentifier=new_writer_instance_identifier)
                dbNewWriterInstances = new_writer_instance_response.get(
                    'DBInstances')
                dbNewWriterInstanceConfiguration = {}
                if dbNewWriterInstances:
                    for dbNewWriterInstance in dbNewWriterInstances:
                        dbNewWriterInstanceConfiguration = dbNewWriterInstance
                new_reader_instance_response = client.describe_db_instances(
                    DBInstanceIdentifier=new_reader_instance_identifier)
                dbNewReaderInstances = new_reader_instance_response.get(
                    'DBInstances')
                dbNewReaderInstanceConfiguration = {}
                if dbNewReaderInstances:
                    for dbNewReaderInstance in dbNewReaderInstances:
                        dbNewReaderInstanceConfiguration = dbNewReaderInstance
                dbNewWriterInstanceStatus = dbNewWriterInstanceConfiguration['DBInstanceStatus']
                dbNewReaderInstanceStatus = dbNewReaderInstanceConfiguration['DBInstanceStatus']
                if dbNewWriterInstanceStatus == 'available' and dbNewReaderInstanceStatus == 'available':
                    print("Both writer and reader instances are in available status.")
                    break
                else:
                    print("Instances creation is in progress...")
            elif currentwriterinstanceclass != newwriterinstanceclass:
                time.sleep(60)
                new_writer_instance_response = client.describe_db_instances(
                    DBInstanceIdentifier=new_writer_instance_identifier)
                dbNewWriterInstances = new_writer_instance_response.get(
                    'DBInstances')
                dbNewWriterInstanceConfiguration = {}
                if dbNewWriterInstances:
                    for dbNewWriterInstance in dbNewWriterInstances:
                        dbNewWriterInstanceConfiguration = dbNewWriterInstance
                dbNewWriterInstanceStatus = dbNewWriterInstanceConfiguration['DBInstanceStatus']
                if dbNewWriterInstanceStatus == 'available':
                    print("Writer instance is in available status.")
                    break
                else:
                    print("Writer instance creation is in progress...")
            elif currentreaderinstanceclass != newreaderinstanceclass:
                time.sleep(60)
                new_reader_instance_response = client.describe_db_instances(
                    DBInstanceIdentifier=new_reader_instance_identifier)
                dbNewReaderInstances = new_reader_instance_response.get(
                    'DBInstances')
                dbNewReaderInstanceConfiguration = {}
                if dbNewReaderInstances:
                    for dbNewReaderInstance in dbNewReaderInstances:
                        dbNewReaderInstanceConfiguration = dbNewReaderInstance
                dbNewReaderInstanceStatus = dbNewReaderInstanceConfiguration['DBInstanceStatus']
                if dbNewReaderInstanceStatus == 'available':
                    print("Reader instance is in available status.")
                    break
                else:
                    print("Reader instance creation is in progress...")
        else:
            print(
                "Reached the maximum number of iterations, exiting.")
            raise

def failover_db_cluster(clusterIdentifier, new_writer_instance_identifier):
    failover_response = client.failover_db_cluster(
        DBClusterIdentifier=clusterIdentifier
    )
    counter = 0
    max_counter = 5
    while True:
        counter = counter+1
        if counter == max_counter:
            print("Reached the maximum number of iterations, exiting.")
            raise
        else:
            response = client.describe_db_clusters(
                DBClusterIdentifier=clusterIdentifier)
            dbClusters = response.get('DBClusters')
            if dbClusters:
                dbClusterMembers = dbClusters[0].get('DBClusterMembers')
                for dbClusterMember in dbClusterMembers:
                    if dbClusterMember['IsClusterWriter']:
                        writer_instance = dbClusterMember['DBInstanceIdentifier']
            if new_writer_instance_identifier == writer_instance:
                print("Failover to new writer instance has been completed")
                break
            else:
                print("Failover to new writer instance is in progress...")
                time.sleep(60)

def delete_db_instances(currentwriterinstanceclass, newwriterinstanceclass, currentreaderinstanceclass, newreaderinstanceclass, old_writer_instance, old_reader_instance):
    if currentwriterinstanceclass != newwriterinstanceclass and currentreaderinstanceclass != newreaderinstanceclass:
        delete_old_writer_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_writer_instance)
        delete_old_reader_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_reader_instance)
        print("Deletion of old writer and reader instance is in progress, and DB Scaling activity has been completed.")
    elif currentwriterinstanceclass != newwriterinstanceclass:
        delete_old_writer_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_writer_instance)
        print("Deletion of the old writer instance is in progress, and the DB Scaling activity has been completed.")
    elif currentreaderinstanceclass != newreaderinstanceclass:
        delete_old_reader_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_reader_instance)
        print("Deletion of old reader instance is in progress, and DB Scaling activity has been completed.")


def main(clusterIdentifier, newwriterinstanceclass, newreaderinstanceclass):
    try:
        print("get_old_writer_instance function starts at: ",
              (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        old_writer_instance, oldWriterInstanceClass, old_reader_instance, oldReaderInstanceClass = get_old_writer_instance(
            clusterIdentifier)
        print("get_old_writer_instance function ends at: ",
              (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        print(f"old_writer_instance: {old_writer_instance} \noldWriterInstanceClass: {oldWriterInstanceClass}\nold_reader_instance: {old_reader_instance}\noldReaderInstanceClass: {oldReaderInstanceClass}")
        if oldWriterInstanceClass == newwriterinstanceclass and oldReaderInstanceClass == newreaderinstanceclass:
            print(
                "Current and new instance size should not be the same for DB Scale Up/Down activity.")
            return
        else:
            # creating reader instance
            newwriterinstancesize = newwriterinstanceclass.split(".")[2]
            newreaderinstancesize = newreaderinstanceclass.split(".")[2]
            writer_instance_initial = old_writer_instance.rpartition("-")[0]
            new_writer_instance_identifier = writer_instance_initial + \
                "-"+"wr"+newwriterinstancesize
            reader_instance_initial = old_reader_instance.rpartition("-")[0]
            new_reader_instance_identifier = reader_instance_initial + \
                "-"+"rd"+newreaderinstancesize
            print(
                f"new_writer_instance_identifier: {new_writer_instance_identifier} \nnew_reader_instance_identifier: {new_reader_instance_identifier}")
            print("Staring the creation of reader instance at: ",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            create_reader_instance(old_writer_instance, old_reader_instance, clusterIdentifier, oldWriterInstanceClass,
                                   newwriterinstanceclass, oldReaderInstanceClass, newreaderinstanceclass, new_writer_instance_identifier, new_reader_instance_identifier)
            # checking newly added instance's status
            new_instances_status(oldWriterInstanceClass,
                                 newwriterinstanceclass,
                                 oldReaderInstanceClass,
                                 newreaderinstanceclass,
                                 new_writer_instance_identifier,
                                 new_reader_instance_identifier)
            print("Creation of reader instance ended at: ",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            if oldWriterInstanceClass != newwriterinstanceclass:
                print("Staring the failover activity: ", (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                failover_db_cluster(clusterIdentifier,new_writer_instance_identifier)
                print("failover activity ends at:",
                      (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            else:
                print("No change in the writer instance so failover is not required.")
            print("Failover activity ended at: ",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            delete_db_instances(oldWriterInstanceClass,newwriterinstanceclass,oldReaderInstanceClass,newreaderinstanceclass,old_writer_instance,old_reader_instance)
    except Exception as e:
        print(str(e))
        raise str(e)
    return "success"


if __name__ == '__main__':
    awsregion = sys.argv[1]
    clusterIdentifier = sys.argv[2]
    newwriterinstanceclass = sys.argv[3]
    newreaderinstanceclass = sys.argv[4]
    client = boto3.client('rds', region_name=awsregion)
    main(clusterIdentifier, newwriterinstanceclass, newreaderinstanceclass)
