import sys
import boto3
from datetime import datetime
import time


def create_db_cluster_snapshot(clusterIdentifier, clusterSnapshotIdentifier):
    response = client.create_db_cluster_snapshot(
        DBClusterSnapshotIdentifier=clusterSnapshotIdentifier,
        DBClusterIdentifier=clusterIdentifier
    )


def snapshot_status(clusterIdentifier, clusterSnapshotIdentifier):
    counter = 0
    max_counter = 15
    while True:
        counter = counter+1
        if counter == max_counter:
            print("Reached the maximum number of iterations, exiting.")
            break
        else:
            response = client.describe_db_cluster_snapshots(
                DBClusterIdentifier=clusterIdentifier,
                DBClusterSnapshotIdentifier=clusterSnapshotIdentifier,
            )
            dbClusterSnapshots = response.get('DBClusterSnapshots')
            dbClusterSnapshotsConfiguration = {}
            if dbClusterSnapshots:
                for dbClusterSnapshot in dbClusterSnapshots:
                    dbClusterSnapshotsConfiguration = dbClusterSnapshot
                    dbClusterSnapshotStatus = dbClusterSnapshotsConfiguration['Status']
            if dbClusterSnapshotStatus == 'available':
                print('DB Cluster snapshot has been created successfully.')
                break
            else:
                print('DB Cluster snapshot creation is in progress...')
            time.sleep(60)


def main(clusterIdentifier):
    try:
        dt_string = datetime.now().strftime("%Y%m%d%H%M%S")
        clusterSnapshotIdentifier = clusterIdentifier+'-'+dt_string
        snapshotStarted = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(
            f"DB Cluster Snapshot: {clusterSnapshotIdentifier}, started at: {snapshotStarted}")
        create_db_cluster_snapshot(
            clusterIdentifier, clusterSnapshotIdentifier)
        snapshot_status(clusterIdentifier, clusterSnapshotIdentifier)
        snapshotCompleted = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(
            f"DB Cluster Snapshot: {clusterSnapshotIdentifier}, completed at: {snapshotCompleted}")
    except Exception as e:
        print(str(e))
        raise str(e)

    return "success"


if __name__ == '__main__':
    awsregion = sys.argv[1]
    clusterIdentifier = sys.argv[2]
    client = boto3.client('rds', region_name=awsregion)
    main(clusterIdentifier)
