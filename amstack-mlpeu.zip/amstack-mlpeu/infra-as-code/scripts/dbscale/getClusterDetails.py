import sys
import boto3
from datetime import datetime
import time


def main():
    try:
        response = client.describe_db_clusters()
        dbClusters = response.get('DBClusters')
        listOfDbCluster = []
        if dbClusters:
            for dbCluster in dbClusters:
                dbClusterStatus = dbCluster.get('Status')
                if dbClusterStatus == 'available':
                    dbClusterIdentifier = dbCluster.get('DBClusterIdentifier')
                    listOfDbCluster.append(dbClusterIdentifier)
        print(listOfDbCluster)
    except Exception as e:
        print(str(e))
        raise str(e)
    return listOfDbCluster


if __name__ == '__main__':
    awsregion = sys.argv[1]
    client = boto3.client('rds', region_name=awsregion)
    main()
