import sys
import boto3
from datetime import datetime
import time


def get_old_writer_instance(clusterIdentifier, newreaderinstanceclass):
    """
    Describing DB Cluster to fetch details of writer and reader instance.
    """
    response = client.describe_db_clusters(
        DBClusterIdentifier=clusterIdentifier)
    dbClusters = response.get('DBClusters')
    if dbClusters:
        dbClusterMembers = dbClusters[0].get('DBClusterMembers')
        for dbClusterMember in dbClusterMembers:
            "If 'IsClusterWriter' is true that means that instance is a writer instance of the DB Cluster"
            if dbClusterMember['IsClusterWriter']:
                old_writer_instance = dbClusterMember['DBInstanceIdentifier']
                old_writer_response = client.describe_db_instances(
                    DBInstanceIdentifier=old_writer_instance)
                oldWriterDbInstance = old_writer_response.get('DBInstances')
                if oldWriterDbInstance:
                    oldWriterInstanceClass = oldWriterDbInstance[0].get(
                        'DBInstanceClass')
            else:
                old_db_instance_identifier = dbClusterMember['DBInstanceIdentifier']
                old_reader_response = client.describe_db_instances(
                    DBInstanceIdentifier=old_db_instance_identifier)
                oldReaderDbInstance = old_reader_response.get('DBInstances')
                old_reader_instance_identifier = oldReaderDbInstance[0].get('DBInstanceIdentifier')
                old_reader_instance_class = oldReaderDbInstance[0].get('DBInstanceClass')
                if old_reader_instance_class != newreaderinstanceclass:
                    old_reader_instance=old_reader_instance_identifier 
                    oldReaderInstanceClass=old_reader_instance_class                 
    return old_writer_instance, oldWriterInstanceClass, old_reader_instance, oldReaderInstanceClass


def failover_db_cluster(clusterIdentifier, new_writer_instance_identifier):
    failover_response = client.failover_db_cluster(
        DBClusterIdentifier=clusterIdentifier
    )
    counter = 0
    max_counter = 5
    while True:
        counter = counter+1
        if counter == max_counter:
            print("Reached the maximum number of iterations, exiting.")
            raise
        else:
            response = client.describe_db_clusters(
                DBClusterIdentifier=clusterIdentifier)
            dbClusters = response.get('DBClusters')
            if dbClusters:
                dbClusterMembers = dbClusters[0].get('DBClusterMembers')
                for dbClusterMember in dbClusterMembers:
                    if dbClusterMember['IsClusterWriter']:
                        writer_instance = dbClusterMember['DBInstanceIdentifier']
            if new_writer_instance_identifier == writer_instance:
                print("Failover to new writer instance has been completed")
                break
            else:
                print("Failover to new writer instance is in progress...")
                time.sleep(60)


def delete_db_instances(currentwriterinstanceclass, newwriterinstanceclass, currentreaderinstanceclass, newreaderinstanceclass, old_writer_instance, old_reader_instance):
    if currentwriterinstanceclass != newwriterinstanceclass and currentreaderinstanceclass != newreaderinstanceclass:
        delete_old_writer_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_writer_instance)
        delete_old_reader_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_reader_instance)
        print("Deletion of old writer and reader instance is in progress, and DB Scaling activity has been completed.")
    elif currentwriterinstanceclass != newwriterinstanceclass:
        delete_old_writer_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_writer_instance)
        print("Deletion of the old writer instance is in progress, and the DB Scaling activity has been completed.")
    elif currentreaderinstanceclass != newreaderinstanceclass:
        delete_old_reader_instance_response = client.delete_db_instance(
            DBInstanceIdentifier=old_reader_instance)
        print("Deletion of old reader instance is in progress, and DB Scaling activity has been completed.")


def main(clusterIdentifier, newwriterinstanceclass, newreaderinstanceclass):
    try:
        print("get_old_writer_instance function starts at:",
              (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        old_writer_instance, oldWriterInstanceClass, old_reader_instance, oldReaderInstanceClass = get_old_writer_instance(
            clusterIdentifier, newreaderinstanceclass)
        print("get_old_writer_instance function ends at:",
              (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        print(f"old_writer_instance: {old_writer_instance} \noldWriterInstanceClass: {oldWriterInstanceClass}\nold_reader_instance: {old_reader_instance}\noldReaderInstanceClass: {oldReaderInstanceClass}")
        if oldWriterInstanceClass == newwriterinstanceclass and oldReaderInstanceClass == newreaderinstanceclass:
            print(
                "Current and new instance sizes should not be the same for DB Scale Up/Down activity.")
            return
        else:
            """ 
            Once reader instances have been created then failover to db cluster, 
            which will convert one of the reader instances into a writer instance based on the eligibility.
            """
            newwriterinstancesize = newwriterinstanceclass.split(".")[2]
            newreaderinstancesize = newreaderinstanceclass.split(".")[2]
            writer_instance_initial = old_writer_instance.rpartition("-")[0]
            new_writer_instance_identifier = writer_instance_initial + \
                "-"+"wr"+newwriterinstancesize
            reader_instance_initial = old_reader_instance.rpartition("-")[0]
            new_reader_instance_identifier = reader_instance_initial + \
                "-"+"rd"+newreaderinstancesize
            print(
                f"new_writer_instance_identifier: {new_writer_instance_identifier} \nnew_reader_instance_identifier: {new_reader_instance_identifier}")
            if oldWriterInstanceClass != newwriterinstanceclass:
                print("Staring the failover activity: ", (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                failover_db_cluster(clusterIdentifier,
                                    new_writer_instance_identifier)
                print("failover activity ends at:",
                      (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            else:
                print("No change in the writer instance so failover is not required.")
            print("Failover activity ended at: ",
                  (datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            delete_db_instances(oldWriterInstanceClass,
                                newwriterinstanceclass,
                                oldReaderInstanceClass,
                                newreaderinstanceclass,
                                old_writer_instance,
                                old_reader_instance)
    except Exception as e:
        print(str(e))
        raise str(e)
    return "success"


if __name__ == '__main__':
    awsregion = sys.argv[1]
    clusterIdentifier = sys.argv[2]
    newwriterinstanceclass = sys.argv[3]
    newreaderinstanceclass = sys.argv[4]
    client = boto3.client('rds', region_name=awsregion)
    main(clusterIdentifier, newwriterinstanceclass, newreaderinstanceclass)
