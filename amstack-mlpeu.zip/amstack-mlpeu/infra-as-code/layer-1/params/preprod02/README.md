### As part of EKS Blue-Green Migration/Upgrade, we have modified/created below stacks and please use new Terraform commands for any new updation.

### Created new stacks/use new commands for below services:
```
Layer1
1. EKS (new Cluster)
2. Security Group (for new Nodegroup only)
3. Service Account IAM Roles (for new Cluster)
```
```
Layer3
1. Hybris Service Account IAM Roles (for each new environment)
```

## Terraform Apply Preprod02 AmStack (Layer 1)

```console
cd infra-as-code
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s vpc-childs
```

### if Eks Cluster is setup using Non-Routable Subnets, Please perform below additonal steps. 
```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s vpc-childs-nonrt
```
```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s nat-gateway
```
### if Eks Cluster is setup using Non-Routable Subnets, Please perform above additonal steps.


```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s routes
```

### If [preprod] only perform the Job test for future readiness. Delete after test
```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s subnet-flowlogs
#Delete after test in Preprod
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s ec2-jump-vms
```

### Configure Session Manager
Configure the Session Manager to send logs to CloudWatch

- Create log group
```console
cd infra-as-code/utils/aws-ssm-configure/preprod02/
bash aws-cloudwatch-create-loggroup.sh --region eu-central-1
```

- Configure SSM
```console
cd infra-as-code/utils/aws-ssm-configure/preprod02/
bash aws-ssm-session-configure.sh
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s s3-gateway-endpoints
```

```console
#New EKS V2 Stack - for Separating EKS Control and data plane ( with Non routable Worker Node subnet )
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s eksv2-blue
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s eksv2-blue
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s kms-key
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s s3-bucket
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s service-account-iam-role-blue
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s service-account-iam-role-blue
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s certificates
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s iam-cross-account
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s web-acl
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s waf
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s cloudfront
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s shield
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s route53
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s db-subnet-group
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s sns-topic
```

```console
# Dependency with sns-topics stack
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s rds-event-subscription
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s db-parameter-group
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s mysql-serverlessv2
```

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s srt
```

```console
#ARN from step [sns-topic] is required to execute this
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s event-bridge-schedule-pattern
```

Generate the configure-aws-auth.sh locally and add roles and execute below
```console
cd infra-as-code/utils/aws-eks-auth-configure/
bash generate-kube-config.sh -c AmStackMlpEuPreprod02BlueEksCluster -r eu-central-1
```

Edit the configure-aws-auth.sh locally and add roles and execute below
```console
cd infra-as-code/utils/aws-eks-auth-configure/preprod
bash configure-aws-auth.sh -c AmStackMlpEuPreprod02BlueEksCluster
```

Add taint tags to the Hybris ASGs
```console
cd infra-as-code/utils/aws-asg-configure/
bash aws-asg-tags-configure.sh -a eks-AmStackMlpEuPreprod02BlueEks -r eu-central-1
```

```console
cd infra-as-code/utils/aws-asg-configure/
bash aws-asg-suspend-process-configure.sh -a eks-AmStackMlpEuPreprod02BlueEks -r eu-central-1
```

Add taint tags to the Hybris ASGs (xxxx = NodeGroup Name)
```console
cd infra-as-code/utils/aws-asg-configure/
bash aws-asg-taints-configure.sh
```

Add dyntrace tags to the Hybris ASG that requires monitoring
```console
cd infra-as-code/utils/aws-asg-configure/
bash aws-asg-dynatrace-tags-configure.sh 
```

```console
cd infra-as-code/utils/aws-secrets-configure/
bash mac-credentials-configure.sh -e test -r us-east-1
```

## Terraform Apply Preprod02-Blue AmStack (Layer 1)

```console
bash setup.sh -r eu-central-1 -l 1 -e preprod02 --reset-terraform true -s security-groups-blue
```