#!/bin/bash
# -----------------------------------------------------------------------------
# Author: SRE Team.
# Purpose: To execute the various Terraform layers.
# -----------------------------------------------------------------------------
# set -e

CURR_DIR="$(pwd)"
ROOT_DIR="infra-as-code"

# execute the script only from 
if [[ $CURR_DIR != *"$ROOT_DIR" ]]; then
  echo "ERROR: Please execute this script from $ROOT_DIR"
  exit 1
fi

echo "===================================================="
echo "SRE Platform Infrastructure deployment (Terraform)"
echo "===================================================="

# Parse the params
while [ $# -gt 0 ]; do
  case "$1" in
  --region | -r)
    if [[ "$1" != *=* ]]; then shift; fi
    REGION="${1#*=}"
    ;;
  --layer | -l)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    LAYER="${1#*=}"
    ;;
  --env | -e)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    ENV="${1#*=}"
    ;;
  --stack | -s)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    STACK="${1#*=}"
    ;;
  --skip-tf-init)
    if [[ "$1" != *=* ]]; then shift; fi
    SKIP_TF_INIT="${1#*=}"
    ;;
  --destroy)
    if [[ "$1" != *=* ]]; then shift; fi
    DESTROY_RESOURCES="${1#*=}"
    ;;
  --auto-approve)
    if [[ "$1" != *=* ]]; then shift; fi
    AUTO_APPROVE="${1#*=}"
    ;;
  --reset-terraform)
    if [[ "$1" != *=* ]]; then shift; fi
    RESET_TF="${1#*=}"
    ;;
  *)
    printf >&2 "ERROR: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

# Log the input params
echo "INFO: Parsed Parameters"
echo REGION=$REGION STACK=$STACK LAYER=$LAYER ENV=$ENV SKIP_TF_INIT=${SKIP_TF_INIT} DESTROY_RESOURCES=${DESTROY_RESOURCES} AUTO_APPROVE=${AUTO_APPROVE} RESET_TF=${RESET_TF}
echo "===================================================="

# Mandatory Param check
if [[ -z $LAYER || -z $ENV || -z $REGION || -z $STACK ]]; then
  echo "ERROR: Please set all the required vars. Required: [--layer --env --region --STACK]"
  exit 1
fi

# Export critical params
export AWS_SDK_LOAD_CONFIG=true
export AWS_DEFAULT_REGION="$REGION"
if [[ `uname` == "Darwin" ]]; then
  echo "INFO: identified as MAC and exporting GO DEBUG param"
  export GODEBUG=asyncpreemptoff=1
fi

WORK_DIR=${CURR_DIR}/layer-${LAYER}/stacks/${STACK}

if [[ -d "$WORK_DIR" ]]; then
  echo "INFO: Workdir set as $WORK_DIR"
else
  echo "ERROR: No such directory $WORK_DIR. Verify the layer number."
fi

# Function Declarations
function cleanup () {
  if [[ ${RESET_TF} == "true" ]]; then
    rm -rf ${WORK_DIR}/.terraform*
    echo "INFO: .terraform reset completed"
    echo "===================================================="   
  fi
  # invoke unlinks
  unlinks
}

function exit_setup () {
  echo "ERROR: ${2} failed"
  echo "===================================================="
  cleanup
  exit ${1}
}

function complete_step () {
    echo "INFO: ${1} completed"
    echo "===================================================="
}

function execute_step () {
  echo "INFO: Executing ${1}"
  ${2}
  EXIT_CODE=$?
  if [[ $EXIT_CODE -eq 0 ]]; then
    complete_step "${1}"
  else
    exit_setup "${EXIT_CODE}" "${1}"
  fi
}

COMMON_DATA_DIR="../../../modules/common-data"
COMMON_PROVIDER_DIR="../../../modules/common-provider"

function unlinks () {
  echo "INFO: unlinks"
  echo "===================================================="
  for m in `ls ${COMMON_DATA_DIR}`
  do
    mylink=${WORK_DIR}/$m
    if [ -L ${mylink} ] ; then
      unlink $mylink
    fi
  done

  for m in `ls ${COMMON_PROVIDER_DIR}`
  do
    mylink=${WORK_DIR}/$m
    if [ -L ${mylink} ] ; then
      unlink $mylink
    fi
  done
}

function symbolic_links () {
  echo "INFO: symbolic_links"
  echo "===================================================="
  unlinks

  for m in `ls ${COMMON_DATA_DIR}`
  do
    ln -s ${COMMON_DATA_DIR}/$m ${WORK_DIR}/.
  done

  for m in `ls ${COMMON_PROVIDER_DIR}`
  do
    ln -s ${COMMON_PROVIDER_DIR}/$m ${WORK_DIR}/.
  done
}

cd ${WORK_DIR}

# link common data and common provider  
symbolic_links

INIT_EXEC="terraform init --backend-config ./backend-${ENV}.tfvars -upgrade=true -reconfigure -compact-warnings"
APPLY_EXEC="terraform apply -var-file=./../../params/${ENV}/terraform-common.tfvars -var-file=./../../params/${ENV}/terraform-${STACK}.tfvars -compact-warnings"
DESTROY_EXEC="terraform destroy -var-file=./../../params/${ENV}/terraform-common.tfvars -var-file=./../../params/${ENV}/terraform-${STACK}.tfvars -compact-warnings"

if [[ ${AUTO_APPROVE} == "true" ]]; then
  echo "INFO: Auto approved enabled for apply."
  APPLY_EXEC="${APPLY_EXEC} -auto-approve"
fi

if [[ $SKIP_TF_INIT != "true" ]]; then
  execute_step "Terraform Init" "${INIT_EXEC}"
else
  echo "WARN: Skipping Terraform Init"
fi

if [[ $DESTROY_RESOURCES != "true" ]]; then
  execute_step "Terraform Apply" "${APPLY_EXEC}"
  # echo "a"
elif [[ $DESTROY_RESOURCES == "true" ]]; then
  execute_step "Terraform Destroy" "${DESTROY_EXEC}"
  # echo "b"
fi

cleanup