import requests
import sys
import json

url = 'https://api.github.com/repos/AmwayCommon/amstack-mlpeu/pulls'
change_req = sys.argv[1]
head = sys.argv[2]
base = sys.argv[3]
token = sys.argv[4]

title = f'[{change_req}]: decoupled-frontend blue green deployment'
body = f''' 
    What this PR does/why we need it: decoupled-frontend blue green deployment
    Which Clusters are affected: AmStackMlpEuProd01EksCluster
    Which Deployment Environment are affected: Prod
    Change Request/JIRA Tickets: {change_req}
'''
data = {'title': title, 'body': body, 'head': head, 'base': base}
headers = {'Authorization': 'token ' + token}
response = requests.post(url,json=data,headers=headers)
pull_request_url=response.json()["html_url"]
print(pull_request_url)