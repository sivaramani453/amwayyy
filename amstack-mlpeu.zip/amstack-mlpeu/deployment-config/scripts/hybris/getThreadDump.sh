#!/bin/bash
# https://jira.amway.com:8444/pages/viewpage.action?spaceKey=DEVS&title=Generate+Heap+Dump+From+Jenkins+Job

while [ $# -gt 0 ]; do
  case "$1" in
  --env | -e)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    ENV="${1#*=}"
    ;;
  --kubeconfig)
    if [[ "$1" != *=* ]]; then shift; fi
    KUBECONFIG="${1#*=}"
    ;;
  --pods-string)
    if [[ "$1" != *=* ]]; then shift; fi
    PODS_STRING="${1#*=}"
    ;;
  --jcmd-filepath)
    if [[ "$1" != *=* ]]; then shift; fi
    JCMD_FILE_PATH="${1#*=}"
    ;;
  --thread-dump-filepath)
    if [[ "$1" != *=* ]]; then shift; fi
    THREAD_DUMP_FILE_PATH="${1#*=}"
    ;;
  --number-of-dumps)
    if [[ "$1" != *=* ]]; then shift; fi
    NUMBER_OF_DUMPS="${1#*=}"
    ;;
  --interval)
    if [[ "$1" != *=* ]]; then shift; fi
    INTERVAL="${1#*=}"
    ;;
  *)
    printf >&2 "Error: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $ENV && -z $KUBECONFIG && -z $JCMD_FILE_PATH && -z $THREAD_DUMP_FILE_PATH && -z $NUMBER_OF_DUMPS && -z $INTERVAL ]]; then
  echo "Error: Please set all the required vars. Required: [--env, --kubeconfig, --jcmd-filepath, --thread-dump-filepath, --number-of-dumps, --interval]"
  exit 1
fi
 
pods=$(echo "$PODS_STRING" | tr ',' '\n')
 
for pod in $pods
do
    echo Extracting process id for pod $pod
    pid=$(kubectl --kubeconfig $KUBECONFIG -n $ENV exec $pod -- ps -ef| grep java|grep HYBRIS_LOG_DIR|grep -v grep| awk '{print $2}')
    echo Starting Thread dump for pod $pod process $pid
    for i in $(seq 1 $NUMBER_OF_DUMPS);
    do
      cmd=$(echo $JCMD_FILE_PATH $pid' Thread.print > '$THREAD_DUMP_FILE_PATH'/$(($(date +%s%N)/1000000)).log')
      kubectl --kubeconfig $KUBECONFIG -n $ENV exec $pod -- su - hybris -c "$(echo $cmd)"
      sleep $INTERVAL
    done
done