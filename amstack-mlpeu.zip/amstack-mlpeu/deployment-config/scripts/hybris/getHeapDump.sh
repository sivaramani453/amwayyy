#!/bin/bash
# https://jira.amway.com:8444/pages/viewpage.action?spaceKey=DEVS&title=Generate+Heap+Dump+From+Jenkins+Job

while [ $# -gt 0 ]; do
  case "$1" in
  --env | -e)
    if [[ "$1" != *=* ]]; then shift; fi # Value is next arg if no `=`
    ENV="${1#*=}"
    ;;
  --kubeconfig)
    if [[ "$1" != *=* ]]; then shift; fi
    KUBECONFIG="${1#*=}"
    ;;
  --pods-string)
    if [[ "$1" != *=* ]]; then shift; fi
    PODS_STRING="${1#*=}"
    ;;
  --jmap-filepath)
    if [[ "$1" != *=* ]]; then shift; fi
    JMAP_FILE_PATH="${1#*=}"
    ;;
  --heap-dump-filepath)
    if [[ "$1" != *=* ]]; then shift; fi
    HEAP_DUMP_FILE_PATH="${1#*=}"
    ;;
  *)
    printf >&2 "Error: Invalid argument\n"
    exit 1
    ;;
  esac
  shift
done

if [[ -z $ENV && -z $KUBECONFIG && -z $PODS_STRING && -z $HEAP_DUMP_FILE_PATH && -z $JMAP_FILE_PATH ]]; then
  echo "Error: Please set all the required vars. Required: [--env, --kubeconfig, --pods-string, --jmap-filepath, --heap-dump-filepath]"
  exit 1
fi

pods=$(echo "$PODS_STRING" | tr ',' '\n')

for pod in $pods
do
  echo Extracting process id for pod $pod
  pid=$(kubectl --kubeconfig $KUBECONFIG -n $ENV exec $pod -- ps -ef| grep java|grep HYBRIS_LOG_DIR|grep -v grep| awk '{print $2}')
  echo Starting dump for pod $pod process $pid
  cmd=$(echo $JMAP_FILE_PATH' -dump:live,format=b,file='$HEAP_DUMP_FILE_PATH'/$(($(date +%s%N)/1000000)).hprof '$pid)
  kubectl --kubeconfig $KUBECONFIG -n $ENV exec $pod -- su - hybris -c "$(echo $cmd)"
  #jmap restricts permissions by default for the dump file. So allow Group to Access.
  cmd=$(echo 'chmod g+r '$HEAP_DUMP_FILE_PATH'/*.hprof')
  kubectl --kubeconfig $KUBECONFIG -n $ENV exec $pod -- su - hybris -c "$(echo $cmd)"
done