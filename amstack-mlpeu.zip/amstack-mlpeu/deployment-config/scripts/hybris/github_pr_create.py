import requests
import sys
import json

url = 'https://api.github.com/repos/AmwayCommon/amstack-mlpeu/pulls'
change_req = sys.argv[1]
image_tag = sys.argv[2]
deploymnt_type = sys.argv[3]
head = sys.argv[4]
base = sys.argv[5]
token = sys.argv[6]

title = f'[{change_req}]: {deploymnt_type} || {image_tag}'
body = f''' 
    What this PR does/why we need it: {deploymnt_type}
    Which Clusters are affected: AmStackMlpEuProd01EksCluster
    Which Deployment Environment are affected: Prod
    Change Request/JIRA Tickets: {change_req}
'''
data = {'title': title, 'body': body, 'head': head, 'base': base}
headers = {'Authorization': 'token ' + token}
response = requests.post(url,json=data,headers=headers)
pull_request_url=response.json()["html_url"]
print(pull_request_url)