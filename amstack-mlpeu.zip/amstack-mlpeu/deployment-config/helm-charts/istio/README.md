# Steps for istio installation
1. [istio-base (CRD)](https://jenkins-apac.amcontroller.amway.net/job/Korea/job/EKS-OnBoarding/job/AmStackKorPreprod01BlueEksCluster/job/Istio/job/Istio-Base-Deploy/)
2. [istiod (ISTIO Controlplane)](https://jenkins-apac.amcontroller.amway.net/job/Korea/job/EKS-OnBoarding/job/AmStackKorPreprod01BlueEksCluster/job/Istio/job/Istiod-Deploy/)
3. [istio gateways (External)](https://jenkins-apac.amcontroller.amway.net/job/Korea/job/EKS-OnBoarding/job/AmStackKorPreprod01BlueEksCluster/job/Istio/job/Istiod-External-Gateway-Deploy/)
4. [istio gateways (Internal)](https://jenkins-apac.amcontroller.amway.net/job/Korea/job/EKS-OnBoarding/job/AmStackKorPreprod01BlueEksCluster/job/Istio/job/Istio-Internal-Ingress-Deploy/)
4. [istio components](https://jenkins-apac.amcontroller.amway.net/job/Korea/job/EKS-OnBoarding/job/AmStackKorPreprod01BlueEksCluster/job/Istio/job/Istio-Components-Deploy/)