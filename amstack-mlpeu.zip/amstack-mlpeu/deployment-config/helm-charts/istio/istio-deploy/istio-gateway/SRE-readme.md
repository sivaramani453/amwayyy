# SRE changes in default helm chart 
"auto" will be populated at runtime by the mutating webhook. See https://istio.io/latest/docs/setup/additional-setup/sidecar-injection/#customizing-injection

In default helm chart, image is set to `auto` where mutating webhook will pick image from Dockerhub, considering rate limit of Dockerhub we changed `image: auto` to `image: {{ .Values.image }}`.