import os
import json

from infobip.util.configuration import Configuration


class InfobipUtils(object):

    HTTP_SUCCESS_STATUSES = {
        'PENDING_WAITING_DELIVERY', 'PENDING_ENROUTE', 'PENDING_ACCEPTED',
        'DELIVERED_TO_OPERATOR', 'DELIVERED_TO_HANDSET'
    }

    COUNTRY_CONFIGURATIONS = {
        'Russia': Configuration(
            username=os.environ['RU_INFOBIP_USERNAME'],
            password=os.environ['RU_INFOBIP_PASSWORD'],
            base_url=os.environ['RU_INFOBIP_URL']),
        'Kazakhstan': Configuration(
            username=os.environ['KZ_INFOBIP_USERNAME'],
            password=os.environ['KZ_INFOBIP_PASSWORD'],
            base_url=os.environ['KZ_INFOBIP_URL'])
    }

    SCENARIO_KEYS = {
        'Russia': os.environ['RU_SCENARIO_KEY'],
        'Kazakhstan': os.environ['KZ_SCENARIO_KEY']
    }

    @staticmethod
    def get_scenario_key_by_country(country):
        return InfobipUtils.SCENARIO_KEYS.get(country)

    @staticmethod
    def get_configuration_by_country(country):
        return InfobipUtils.COUNTRY_CONFIGURATIONS.get(country)

    @staticmethod
    def parse_response(infobip_response):
        responses = []
        for message in infobip_response.messages:
            responses.append(
                {
                    "messageId": message.message_id,
                    "statusCode": 'SUCCESS' if message.status.name in InfobipUtils.HTTP_SUCCESS_STATUSES else 'ERROR',
                    "statusMessage": message.status.description
                }
            )
        return {
            "isBase64Encoded": False,
            "statusCode": 200,
            "headers": {},
            "body": json.dumps({
                "messages": responses
            })
        }
