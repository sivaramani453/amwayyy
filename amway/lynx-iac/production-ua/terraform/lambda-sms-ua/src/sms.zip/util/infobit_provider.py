from infobip.api.model.omni.Destination import Destination
from infobip.api.model.omni.To import To
from infobip.api.model.omni.send.OmniAdvancedRequest import OmniAdvancedRequest
from infobip.api.model.omni.send.SmsData import SmsData
from infobip.api.model.omni.send.ViberData import ViberData
from infobip.api.model.sms.mt.send.textual.SMSTextualRequest import SMSTextualRequest
from infobip.clients import send_advanced_omni_message
from infobip.clients import send_single_textual_sms
from template.template_client import TemplateClient
from util.infobip_utils import InfobipUtils
from util.message_provider import MessageProviderInterface


class InfobitProvider(MessageProviderInterface):

    def __init__(self, country) -> None:
        self.country = country

    def send_sms(self, phone_number: str, text: str):
        request = SMSTextualRequest()
        request.to = phone_number
        request.text = text

        send_sms_client = send_single_textual_sms(InfobipUtils.get_configuration_by_country(self.country))
        infobip_response = send_sms_client.execute(request)
        return InfobipUtils.parse_response(infobip_response)

    def send_omni(self, text: str, data: dict):
        request = OmniAdvancedRequest()
        request.sms = self.__get_sms_data(text)
        request.viber = self.__get_viber_data(text)
        request.destinations = self.__get_destinations(data['phoneNumbers'])
        request.callback_data = TemplateClient.get_template_name(data['templateId'])
        request.scenario_key = InfobipUtils.get_scenario_key_by_country(data['country'])

        client = send_advanced_omni_message(InfobipUtils.get_configuration_by_country(data['country']))
        infobip_response = client.execute(request)
        return InfobipUtils.parse_response(infobip_response)

    @staticmethod
    def __get_destinations(phone_numbers):
        destinations = []
        for phone_number in phone_numbers:
            to = To()
            to.phone_number = phone_number
            destination = Destination()
            destination.to = to
            destinations.append(destination)

        return destinations

    @staticmethod
    def __get_sms_data(text: str) -> SmsData:
        sms_data = SmsData()
        sms_data.text = text
        return sms_data

    @staticmethod
    def __get_viber_data(text: str) -> ViberData:
        viber_data = ViberData()
        viber_data.validity_period = 35
        viber_data.validity_period_time_unit = "SECONDS"
        viber_data.text = text
        return viber_data
