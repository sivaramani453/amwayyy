# -*- coding: utf-8 -*-


class MessageProviderInterface:
    def send_sms(self, phone_number: str, text: str):
        pass

    def send_omni(self, text: str, data: dict):
        pass


def message_provider_factory(country: str) -> MessageProviderInterface:
    if country == 'Russia' or country == 'Kazakhstan':
        from util.infobit_provider import InfobitProvider
        return InfobitProvider(country)

    if country == 'Ukraine':
        from util.gms_provider import GMSProvider
        return GMSProvider()

    raise Exception("Provider for country '%s' not implemented" % country)
