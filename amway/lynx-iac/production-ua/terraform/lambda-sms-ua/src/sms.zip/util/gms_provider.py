import json
import os

from gms.gms_api import GMSConfiguration, GMSApi
from gms.models import SmsMessage, ViberMessage, OmniMessage, GMSApiException
from util.message_provider import MessageProviderInterface


class GMSProvider(MessageProviderInterface):
    CONFIGURATION = GMSConfiguration(
        os.environ['UA_GMS_USERNAME'],
        os.environ['UA_GMS_PASSWORD'],
        os.environ['UA_GMS_API_URL'],
        os.environ.get('UA_GMS_SENDER', "AMWAY"),
    )

    def __init__(self) -> None:
        self.gms = GMSApi(GMSProvider.CONFIGURATION)

    def send_sms(self, phone_number: str, text: str):
        return self.__execute(lambda: self.gms.send_sms(phone_number, SmsMessage(text)))

    def send_omni(self, text: str, data: dict):
        if len(data['phoneNumbers']) > 1:
            raise Exception("Multiple phone numbers are not supported")

        message = OmniMessage(sms=SmsMessage(text), viber=ViberMessage(text))
        return self.__execute(lambda: self.gms.send_omni(data['phoneNumbers'][0], message))

    @staticmethod
    def __execute(runnable):
        try:
            message = runnable()
            return {
                "isBase64Encoded": False,
                "statusCode": 200,
                "headers": {},
                "body": json.dumps({
                    "messages": [{
                        "messageId": message.id,
                        "statusCode": 'SUCCESS',
                        "statusMessage": 'SUCCESS'
                    }]
                })
            }

        except GMSApiException as e:
            return {
                "isBase64Encoded": False,
                "statusCode": 200,
                "headers": {},
                "body": json.dumps({
                    "messages": [{
                        "statusCode": 'ERROR',
                        "statusMessage": " ".join(str(x) for x in e.args)
                    }]
                })
            }
